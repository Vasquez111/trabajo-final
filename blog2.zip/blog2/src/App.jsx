import React from "react"
import MenuLateral from "./components/menulateral";
import MenuSuperior from "./components/menusuperior";
import Contenedor from "./components/contenedor";
import Tarjeta from "./components/tarjetas";
import Pie from "./components/pie";
import { Routes, Route } from "react-router-dom";
import Home from "./components/pages/home";
import Portafolio from "./components/pages/portafolio";
import Contact from "./components/pages/contact";
import About from "./components/pages/about";




function App() {
  
  return (
    <>
    <Routes>
      <Route path= "/" element={ <Home/>} />
      <Route path= "/About" element={ <About/>} />
      <Route path= "/Portafolio" element={ <Portafolio/>} />
      <Route path= "/Contacto" element={ <Contact/>} />
    </Routes>

     
      
    </>
    
  )
}

export default App
