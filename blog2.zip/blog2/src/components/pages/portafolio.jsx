import React from "react";

function Portafolio(){
    return <h1>Pagina Portafolio</h1>
}

export default Portafolio;