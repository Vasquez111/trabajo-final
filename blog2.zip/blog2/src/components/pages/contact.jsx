import React from "react";

function Contact(){
    return <h1>Pagina Contact</h1>
}

export default Contact;