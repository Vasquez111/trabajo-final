import React from "react";

function About(){
    return <h1>Pagina About</h1>
}

export default About;
