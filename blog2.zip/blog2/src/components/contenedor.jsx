import React from "react";
import Tarjeta from "./tarjetas";

let noticias = [
    {
        titulo:"Accidente en el tranvia", 
        descripcion:"sdsdsdsdsdsdsdsd noticia 1",
        imagen: "https://files.alerta.rcnradio.com/alerta_paisa/public/styles/amp_metadata_content_image_min_696px_wide/public/2023-11/accidente_tranvia_medellin.jpeg?XjdOSBFPkt6zSZCYKqHhVOYiNqKs8TW1&itok=vzLsvj3t"
    },
    {
        titulo:"Cerraron el peñol", 
        descripcion:"sdsdsdsdsdsdsdsd noticia 2",
        imagen: "https://www.elpais.com.co/resizer/eBGBdMpMI0Q8mn2dn5ndizTpZ3w=/1280x720/smart/filters:format(jpg):quality(80)/cloudfront-us-east-1.images.arcpublishing.com/semana/2GKQQ6KMRNELPHUTRHCRI7W2BU.png"
    },
    {
        titulo:"El agucero Daño Halloween", 
        descripcion:"sdsdsdsdsdsdsdsd noticia 3",
        imagen: "https://siteweboriginalh13.s3.amazonaws.com/wp-content/uploads/2023/11/Tiburones-en-Medellin.jpg"
    }
]

function Contenedor() {
    return (
        <div className="w3-row-padding">
            {
                noticias.map((info)=>( 
                    <Tarjeta imagen={info.imagen} descripcion={info.descripcion} titulo={info.titulo} /> 
                ))
            }
        </div>
    )
}

export default Contenedor;